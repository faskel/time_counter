from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin, UserAdmin

# Register your models here.
from .models import WorkDay, Action, User, MonthTransfer, Birthday, Holiday, Department, TodayPhrase, Task, TaskComment, TaskPriority, TaskTopic, TaskCoAssigneeApproval, TaskHistory, TaskDependency


def set_normal_day(modeladmin, request, queryset):
    """Устанавливает тип дня для выбранных записей на 'Обычный день'."""
    updated_count = queryset.update(type='ND')
    modeladmin.message_user(
        request,
        f"Успешно изменено {updated_count} записей на тип 'Обычный день'."
    )


set_normal_day.short_description = "Установить выбранным дням тип 'Обычный день'"


def set_weekend_day(modeladmin, request, queryset):
    """Устанавливает тип дня для выбранных записей на 'Выходной день'."""
    updated_count = queryset.update(type='WD')
    modeladmin.message_user(
        request,
        f"Успешно изменено {updated_count} записей на тип 'Выходной день'."
    )


set_weekend_day.short_description = "Установить выбранным дням тип 'Выходной день'"


def set_short_day(modeladmin, request, queryset):
    """Устанавливает тип дня для выбранных записей на 'Короткий день'."""
    updated_count = queryset.update(type='SMD')
    modeladmin.message_user(
        request,
        f"Успешно изменено {updated_count} записей на тип 'Короткий день'."
    )


set_short_day.short_description = "Установить выбранным дням тип 'Короткий день'"


def set_vacation_day(modeladmin, request, queryset):
    """Устанавливает тип дня для выбранных записей на 'Отпуск'."""
    updated_count = queryset.update(type='VL')
    modeladmin.message_user(
        request,
        f"Успешно изменено {updated_count} записей на тип 'Отпуск'."
    )


set_vacation_day.short_description = "Установить выбранным дням тип 'Отпуск'"


def set_holiday(modeladmin, request, queryset):
    """Устанавливает тип дня для выбранных записей на 'Праздник'."""
    updated_count = queryset.update(type='HD')
    modeladmin.message_user(
        request,
        f"Успешно изменено {updated_count} записей на тип 'Праздник'."
    )


set_holiday.short_description = "Установить выбранным дням тип 'Праздник'"


def set_mk_type(modeladmin, request, queryset):
    """Устанавливает entry_type для выбранных записей на 'mk'."""
    updated_count = queryset.update(entry_type='mk')
    modeladmin.message_user(
        request,
        f"Успешно изменено {updated_count} записей на тип 'МК'."
    )


# Добавляем короткое описание для действия, которое будет отображаться в админке
set_mk_type.short_description = "Установить выбранным записям тип 'МК'"


def set_default_type(modeladmin, request, queryset):
    """Устанавливает entry_type для выбранных записей на 'default'."""
    updated_count = queryset.update(entry_type='default')
    modeladmin.message_user(
        request,
        f"Успешно изменено {updated_count} записей на тип 'default'."
    )


set_default_type.short_description = "Установить выбранным записям тип 'default'"


@admin.register(WorkDay)
class WorkDayAdmin(admin.ModelAdmin):
    list_display = ('user', 'date_stamp', 'type')
    list_filter = ('user', 'type', 'date_stamp')
    search_fields = ('user__username', 'date_stamp')
    date_hierarchy = 'date_stamp'
    actions = [set_normal_day, set_weekend_day, set_short_day, set_vacation_day, set_holiday]


@admin.register(Action)
class ActionAdmin(admin.ModelAdmin):
    list_display = ('workday', 'time_stamp', 'status_gate', 'order', 'entry_type')
    list_filter = ('workday__user', 'time_stamp', 'status_gate', 'entry_type')
    search_fields = ('workday__user__username', 'time_stamp')
    raw_id_fields = ('workday',)
    date_hierarchy = 'time_stamp'
    actions = [set_mk_type, set_default_type]

# class UserAdmin(BaseUserAdmin):
#     fieldsets = (BaseUserAdmin.fieldsets + ('Личная информация',{'fields':('first_name','last_name')},'Тип учетной записи),'account_type')
#     # day_type = 'account_type'
#     admin.site.register(User, UserAdmin)

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'get_users_count', 'get_head')
    search_fields = ('name',)

    def get_users_count(self, obj):
        return obj.users.count()
    get_users_count.short_description = "Количество сотрудников"

    def get_head(self, obj):
        head = obj.users.filter(is_department_head=True).first()
        return head if head else "—"
    get_head.short_description = "Начальник подразделения"


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = (
        'username',
        'first_name',
        'last_name',
        'department',
        'is_administrator',
        'is_department_head',
        'account_type',
        'tracker',
        'pk',
        'is_staff',
        'is_superuser',
    )
    list_filter = (
        'department',
        'is_administrator',
        'is_department_head',
        'account_type',
    )
    search_fields = (
        'username',
        'first_name',
        'last_name',
    )

    fieldsets = [
        ('Личная информация', {
            'fields': [
                'username', 'first_name', 'last_name', 'department', 'is_administrator', 'is_staff', 'is_superuser', 'is_department_head', 'account_type', 'tracker', 'password',
            ],
        }),
    ]


@admin.register(MonthTransfer)
class MonthTransferAdmin(admin.ModelAdmin):
    list_display = ('user', 'from_year', 'from_month', 'to_year', 'to_month', 'amount_seconds', 'description', 'created_at')
    list_filter = ('user', 'from_year', 'to_year')
    search_fields = ('user__username', 'description')


@admin.register(Birthday)
class BirthdayAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'date')
    list_filter = ('date',)
    search_fields = ('full_name',)
    ordering = ('date',)


@admin.register(Holiday)
class HolidayAdmin(admin.ModelAdmin):
    list_display = ('date', 'day_type', 'description')
    list_filter = ('day_type', 'date')
    search_fields = ('description', 'date')
    ordering = ('date',)


@admin.register(TodayPhrase)
class TodayPhraseAdmin(admin.ModelAdmin):
    list_display = ('phrase', 'is_active')
    list_editable = ('is_active',)
    search_fields = ('phrase',)




@admin.register(TaskTopic)
class TaskTopicAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)


@admin.register(TaskPriority)
class TaskPriorityAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'color_code')
    list_editable = ('name', 'color_code')
    ordering = ('code',)


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('title', 'topic', 'priority', 'assigned_to', 'created_by', 'due_date', 'schedule_type', 'status')
    list_filter = ('topic', 'priority', 'status', 'schedule_type', 'due_date', 'assigned_to', 'created_by')
    search_fields = ('title', 'description', 'assigned_to__username', 'created_by__username', 'schedule_number')
    filter_horizontal = ('co_assignees',)
    date_hierarchy = 'due_date'


@admin.register(TaskCoAssigneeApproval)
class TaskCoAssigneeApprovalAdmin(admin.ModelAdmin):
    list_display = ('task', 'user', 'is_approved', 'approved_at')
    list_filter = ('is_approved', 'user')
    search_fields = ('task__title', 'user__username')


@admin.register(TaskHistory)
class TaskHistoryAdmin(admin.ModelAdmin):
    list_display = ('task', 'actor', 'action_type', 'created_at', 'description')
    list_filter = ('action_type', 'created_at', 'actor')
    search_fields = ('task__title', 'description', 'actor__username')


@admin.register(TaskComment)
class TaskCommentAdmin(admin.ModelAdmin):
    list_display = ('task', 'author', 'created_at', 'text')
    list_filter = ('created_at', 'author')
    search_fields = ('text', 'task__title', 'author__username')


@admin.register(TaskDependency)
class TaskDependencyAdmin(admin.ModelAdmin):
    list_display = ('task', 'depends_on', 'relation_type', 'lag_lead_days', 'created_at')
    list_filter = ('relation_type', 'created_at')
    search_fields = ('task__title', 'depends_on__title')





