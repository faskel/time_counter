from django.db.models import Q
from .models import Task

def planner_notifications(request):
    """
    Контекстный процессор для индикатора уведомлений около кнопки «Планировщик».
    - Для сотрудников: количество новых/непрочитанных назначенных задач.
    - Для администратора: количество задач со сменой статуса.
    """
    if not hasattr(request, 'user') or not request.user.is_authenticated:
        return {
            'planner_unread_count': 0,
            'head_changed_tasks_count': 0,
            'has_planner_notifications': False,
        }

    user = request.user

    # Непрочитанные поступившие задачи сотрудника
    unread_q = Q(assigned_to=user, is_read_by_assignee=False)
    if user.department:
        unread_q &= (Q(department=user.department) | Q(department__isnull=True))
    planner_unread_count = Task.objects.filter(unread_q).count()

    # Задачи с изменившимся статусом для администратора / начальника подразделения
    head_changed_tasks_count = 0
    is_admin = bool(getattr(user, 'is_administrator', False) or getattr(user, 'is_department_head', False) or user.is_staff or user.is_superuser)
    if is_admin:
        head_q = Q(status_changed_for_head=True)
        if user.department:
            head_q &= Q(department=user.department)
        head_changed_tasks_count = Task.objects.filter(head_q).count()

    total_notifications = planner_unread_count + head_changed_tasks_count

    return {
        'planner_unread_count': planner_unread_count,
        'head_changed_tasks_count': head_changed_tasks_count,
        'total_planner_notifications': total_notifications,
        'has_planner_notifications': total_notifications > 0,
    }
