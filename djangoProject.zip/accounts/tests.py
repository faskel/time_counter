from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import Task, TaskComment, TaskPriority

User = get_user_model()

class TaskCommentPermissionsTestCase(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='password123')
        self.user2 = User.objects.create_user(username='user2', password='password123')
        
        self.priority = TaskPriority.objects.create(code=1, name='Средний')
        self.task = Task.objects.create(
            title='Тестовая задача',
            description='Описание задачи',
            created_by=self.user1,
            assigned_to=self.user2,
            priority=self.priority,
            due_date='2026-10-02'
        )

    def test_author_can_edit_latest_comment(self):
        self.client.login(username='user1', password='password123')
        comment = TaskComment.objects.create(task=self.task, author=self.user1, text='Первый коммент')

        url = reverse('edit_task_comment', kwargs={'comment_id': comment.id})
        response = self.client.post(url, {'text': 'Измененный коммент'})
        
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json().get('success'))
        comment.refresh_from_db()
        self.assertEqual(comment.text, 'Измененный коммент')

    def test_author_cannot_edit_comment_if_newer_exists(self):
        self.client.login(username='user1', password='password123')
        comment1 = TaskComment.objects.create(task=self.task, author=self.user1, text='Первый коммент')
        comment2 = TaskComment.objects.create(task=self.task, author=self.user2, text='Второй коммент')

        url = reverse('edit_task_comment', kwargs={'comment_id': comment1.id})
        response = self.client.post(url, {'text': 'Попытка изменения'})
        
        self.assertEqual(response.status_code, 400)
        self.assertFalse(response.json().get('success'))
        comment1.refresh_from_db()
        self.assertEqual(comment1.text, 'Первый коммент')

    def test_non_author_cannot_edit_comment(self):
        self.client.login(username='user2', password='password123')
        comment = TaskComment.objects.create(task=self.task, author=self.user1, text='Коммент пользователя 1')

        url = reverse('edit_task_comment', kwargs={'comment_id': comment.id})
        response = self.client.post(url, {'text': 'Попытка изменения пользователем 2'})
        
        self.assertEqual(response.status_code, 403)
        self.assertFalse(response.json().get('success'))

    def test_author_can_delete_latest_comment(self):
        self.client.login(username='user1', password='password123')
        comment = TaskComment.objects.create(task=self.task, author=self.user1, text='Коммент для удаления')

        url = reverse('delete_task_comment', kwargs={'comment_id': comment.id})
        response = self.client.post(url)
        
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json().get('success'))
        self.assertFalse(TaskComment.objects.filter(id=comment.id).exists())

    def test_author_cannot_delete_comment_if_newer_exists(self):
        self.client.login(username='user1', password='password123')
        comment1 = TaskComment.objects.create(task=self.task, author=self.user1, text='Первый коммент')
        comment2 = TaskComment.objects.create(task=self.task, author=self.user2, text='Второй коммент')

        url = reverse('delete_task_comment', kwargs={'comment_id': comment1.id})
        response = self.client.post(url)
        
        self.assertEqual(response.status_code, 400)
        self.assertFalse(response.json().get('success'))
        self.assertTrue(TaskComment.objects.filter(id=comment1.id).exists())

    def test_non_author_cannot_delete_comment(self):
        self.client.login(username='user2', password='password123')
        comment = TaskComment.objects.create(task=self.task, author=self.user1, text='Коммент пользователя 1')

        url = reverse('delete_task_comment', kwargs={'comment_id': comment.id})
        response = self.client.post(url)
        
        self.assertEqual(response.status_code, 403)
        self.assertFalse(response.json().get('success'))
        self.assertTrue(TaskComment.objects.filter(id=comment.id).exists())

    def test_clear_notifications(self):
        self.task.is_read_by_assignee = False
        self.task.status_changed_for_head = True
        self.task.save()

        self.client.login(username='user2', password='password123')
        url = reverse('clear_head_notifications')
        response = self.client.post(url)
        
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json().get('success'))
        self.task.refresh_from_db()
        self.assertTrue(self.task.is_read_by_assignee)


class TaskDependencyTestCase(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='depuser', password='password123', is_administrator=True)
        self.priority = TaskPriority.objects.create(code=1, name='Высокий')
        self.task1 = Task.objects.create(
            title='Задача 1',
            created_by=self.user,
            assigned_to=self.user,
            priority=self.priority,
            due_date='2026-10-10'
        )
        self.task2 = Task.objects.create(
            title='Задача 2',
            created_by=self.user,
            assigned_to=self.user,
            priority=self.priority,
            due_date='2026-10-15'
        )
        self.task3 = Task.objects.create(
            title='Задача 3',
            created_by=self.user,
            assigned_to=self.user,
            priority=self.priority,
            due_date='2026-10-20'
        )
        self.client.login(username='depuser', password='password123')

    def test_search_tasks_for_dependencies(self):
        url = reverse('search_tasks_for_dependencies')
        resp = self.client.get(url, {'q': 'Задача 2', 'exclude_id': self.task1.id})
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertTrue(data['success'])
        task_ids = [t['id'] for t in data['tasks']]
        self.assertIn(self.task2.id, task_ids)
        self.assertNotIn(self.task1.id, task_ids)

    def test_create_and_edit_dependencies(self):
        edit_url = reverse('edit_task', kwargs={'task_id': self.task2.id})
        import json
        deps = [{'depends_on_id': self.task1.id, 'relation_type': 'FS', 'lag_lead_days': 2}]
        resp = self.client.post(edit_url, {
            'title': self.task2.title,
            'due_date': '2026-10-15',
            'dependencies': json.dumps(deps)
        })
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(resp.json().get('success'))
        self.assertTrue(self.task2.dependencies.filter(depends_on=self.task1, relation_type='FS', lag_lead_days=2).exists())

    def test_prevent_cycle_deadlock(self):
        import json
        # Task 2 depends on Task 1
        from accounts.models import TaskDependency
        TaskDependency.objects.create(task=self.task2, depends_on=self.task1, relation_type='FS', lag_lead_days=0)
        # Task 3 depends on Task 2
        TaskDependency.objects.create(task=self.task3, depends_on=self.task2, relation_type='FS', lag_lead_days=0)

        # Now try to make Task 1 depend on Task 3 -> creates cycle 1 -> 3 -> 2 -> 1
        edit_url = reverse('edit_task', kwargs={'task_id': self.task1.id})
        deps = [{'depends_on_id': self.task3.id, 'relation_type': 'FS', 'lag_lead_days': 0}]
        resp = self.client.post(edit_url, {
            'title': self.task1.title,
            'due_date': '2026-10-10',
            'dependencies': json.dumps(deps)
        })
        self.assertEqual(resp.status_code, 400)
        self.assertIn('циклическая зависимость', resp.json().get('message', ''))

    def test_prevent_self_dependency(self):
        import json
        edit_url = reverse('edit_task', kwargs={'task_id': self.task1.id})
        deps = [{'depends_on_id': self.task1.id, 'relation_type': 'FS', 'lag_lead_days': 0}]
        resp = self.client.post(edit_url, {
            'title': self.task1.title,
            'due_date': '2026-10-10',
            'dependencies': json.dumps(deps)
        })
        self.assertEqual(resp.status_code, 400)
        self.assertIn('задача не может зависеть от самой себя', resp.json().get('message', ''))

